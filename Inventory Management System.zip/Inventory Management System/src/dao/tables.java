/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class tables {

    public static void main(String[] args) {
        Connection con = null;
        Statement st = null;
        try {
            con = ConnectionProvider.getCon();
            st = con.createStatement();
            // Uncomment this if table creation is needed
            // st.executeUpdate("CREATE TABLE appuser (appuser_pk INT AUTO_INCREMENT PRIMARY KEY, userRole VARCHAR(50), name VARCHAR(200), mobileNumber VARCHAR(50), email VARCHAR(200), password VARCHAR(50), address VARCHAR(200), status VARCHAR(50))");

            // Fixed SQL INSERT statement
//            st.executeUpdate("INSERT INTO appuser (userRole, name, mobileNumber, email, password, address, status) VALUES ('SuperAdmin', 'Super Admin', '12345', 'superadmin@testmail.com', 'admin', 'Pakistan', 'Active')");
//              st.executeUpdate("CREATE TABLE category (category_pk INT AUTO_INCREMENT PRIMARY KEY, name varchar(200))");
//            st.executeUpdate("CREATE TABLE product (product_pk INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(200), quantity INT, price INT, description VARCHAR(500), category_fk INT)");
//            st.executeUpdate("CREATE TABLE customer (customer_pk INT AUTO_INCREMENT PRIMARY KEY,name varchar(200),mobileNumber varchar(50),email varchar(200))");
            st.executeUpdate("CREATE TABLE orderDetail (order_pk INT AUTO_INCREMENT PRIMARY KEY,orderId varchar(200),customer_fk int,orderDate varchar(200), totalPaid int)");

            JOptionPane.showMessageDialog(null, "Table Created Successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error closing resources: " + e);
            }
        }
    }
}
